package vazqueztadeo_parcial1_122;

public class NaveDeExploracion extends Nave implements Explorable{
    private TipoMision tipoMision;

    public NaveDeExploracion(String nombre, int capacidadDeTripulacion, int anioDeLanzamiento, TipoMision tipoMision) {
        super(nombre, capacidadDeTripulacion, anioDeLanzamiento);
        this.tipoMision = tipoMision;
    }
    
    @Override
    public void explorar(){
        System.out.println("Nave de exploracion llamada " + super.getNombre() + " realizando tareas de EXPLORACION...");
    }

    @Override
    public String toString() {
        return super.toString() + " // NaveDeExploracion{" + "tipoMision=" + tipoMision + '}';
    }
    
    public boolean esTipoMision(TipoMision tipo){
        return this.tipoMision == tipo;
    }
    
    
}
