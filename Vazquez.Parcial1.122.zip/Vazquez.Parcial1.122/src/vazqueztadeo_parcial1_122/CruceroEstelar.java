package vazqueztadeo_parcial1_122;

public class CruceroEstelar extends Nave implements Mantenible{
    private int cantidadPasajerosMaxima;

    public CruceroEstelar(String nombre, int capacidadDeTripulacion, int anioDeLanzamiento, int cantidadPasajerosMaxima) {
        super(nombre, capacidadDeTripulacion, anioDeLanzamiento);
        this.cantidadPasajerosMaxima = cantidadPasajerosMaxima;
    }
    
    @Override
    public void realizarMantenimiento(){
        System.out.println("Crucero Estelar llamado " + super.getNombre() + " realizando tareas de mantenimiento...");
    }

    @Override
    public String toString() {
        return super.toString() + " // CruceroEstelar{" + "cantidadPasajerosMaxima=" + cantidadPasajerosMaxima + '}';
    }
    
    
    
}
