package vazqueztadeo_parcial1_122;

public interface Explorable {
    void explorar();
}
