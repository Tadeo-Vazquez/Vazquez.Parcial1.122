package vazqueztadeo_parcial1_122;

public class SinNavesEnLaAgenciaException extends RuntimeException {
    public static String MSG = "No se encuentran naves en la agencia";
        
    public SinNavesEnLaAgenciaException() {
        this(MSG);
    }

    public SinNavesEnLaAgenciaException(String msg) {
        super(msg);
    }


}