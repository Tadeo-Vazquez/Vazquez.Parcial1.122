package vazqueztadeo_parcial1_122;

import java.util.ArrayList;

public class AgenciaDeNaves {
    private ArrayList<Nave> naves;
    
    public AgenciaDeNaves(){
        naves = new ArrayList<>();    
    }
    
    public void agregarNave(Nave nave){
        try{
        validarNave(nave);
        naves.add(nave);}
        catch(RuntimeException e){
            System.out.println("ERROR no se puede agregar la nave: " + e.getMessage());
        }
    }
    private void validarNave(Nave nave){
        if (nave == null){
            throw new NullPointerException("Nave nula");
        }
        if (naves.contains(nave)){
            throw new NaveRepetidaException();
        }
    }
    
    private void validarSinNavesDisponibles(){
        if (naves.isEmpty()){
            throw new SinNavesEnLaAgenciaException();
        }
    }
    
    public void mostrarNaves(){
        try{
        validarSinNavesDisponibles();  
        for (Nave n : naves){
            System.out.println(n);
        }}catch (RuntimeException e){
            System.out.println("ERROR no se puede mostrar naves: " + e.getMessage());
        }
    }
    
    
    public void iniciarExploracion(){
        try{
        validarSinNavesDisponibles();
        for (Nave n : naves){
            enviarAExplorar(n);
        }
        System.out.println("Los cruceros estelares no pueden explorar.");}
        catch (RuntimeException e){
            System.out.println("ERROR no se puede iniciar exploracion: " + e.getMessage());
        }
    }
    
    private void enviarAExplorar(Nave n){
        if (n instanceof Explorable e){
                e.explorar();
        }
    }
    
    public ArrayList<Nave> filtrarPorTipoMision(TipoMision tipo){
        ArrayList<Nave> navesPorTipo = new ArrayList<>();
        for (Nave n : naves){
            if (n instanceof NaveDeExploracion e && e.esTipoMision(tipo)){
                System.out.println(e);
                navesPorTipo.add(e);
            }
        }
        if (navesPorTipo.isEmpty()){
            System.out.println("No hay naves del tipo: " + tipo.name());
        }
        return navesPorTipo;
    }

    
    
}
