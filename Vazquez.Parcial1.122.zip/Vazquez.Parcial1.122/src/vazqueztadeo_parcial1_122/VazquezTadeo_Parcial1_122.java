package vazqueztadeo_parcial1_122;

public class VazquezTadeo_Parcial1_122 {

    public static void main(String[] args) {
        AgenciaDeNaves miAgencia = new AgenciaDeNaves();
        hardcodearAgencia(miAgencia);
        
    }
    
    public static void hardcodearAgencia(AgenciaDeNaves a){
        a.agregarNave(new Carguero("Galactica",150,2025,300));
        // se informa que no se agrega la nave repetida y luego se agregan las demas
        a.agregarNave(new CruceroEstelar("Galactica",80,2025,250));
               
        a.agregarNave(new Carguero("carguero2",200,2024,400));
        a.agregarNave(new CruceroEstelar("crucero1",120,2023,150));
        a.agregarNave(new CruceroEstelar("crucero2",180,2023,250));
        a.agregarNave(new NaveDeExploracion("exoplorer1",7,2022,TipoMision.INVESTIGACION));
        a.agregarNave(new NaveDeExploracion("exoplorer2",7,2022,TipoMision.INVESTIGACION));
        a.agregarNave(new NaveDeExploracion("explorer3",12,2021,TipoMision.CARTOGRAFIA));
        
        System.out.println("--------------------------------------");
        a.mostrarNaves();
        System.out.println("--------------------------------------");
        a.iniciarExploracion();
        System.out.println("--------------------------------------");
        a.filtrarPorTipoMision(TipoMision.INVESTIGACION);
        

        
    }
    
}
