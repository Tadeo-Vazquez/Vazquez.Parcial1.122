package vazqueztadeo_parcial1_122;

public class NaveRepetidaException extends RuntimeException {
    public static String MSG = "La nave ya se encuentra en la agencia";
    
    public NaveRepetidaException() {
        this(MSG);
    }
    public NaveRepetidaException(String msg) {
        super(msg);
    }
}
