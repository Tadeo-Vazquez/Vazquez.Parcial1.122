package vazqueztadeo_parcial1_122;

import java.time.LocalDate;
import java.util.Objects;

public abstract class Nave {
    private String nombre;
    private int capacidadDeTripulacion;
    private int anioDeLanzamiento;

    public Nave(String nombre, int capacidadDeTripulacion, int anioDeLanzamiento) {
        try{
        validarAnioLanzamiento(anioDeLanzamiento);
        this.nombre = nombre;
        this.capacidadDeTripulacion = capacidadDeTripulacion;
        this.anioDeLanzamiento = anioDeLanzamiento;}
        catch (RuntimeException e){
            System.out.println("ERROR;No se pudo crear la nave: " + e.getMessage());
        }
        
    }
    
    private void validarAnioLanzamiento(int anioLanzamiento){
        if (anioLanzamiento > LocalDate.now().getYear()){
            throw new IllegalArgumentException("Anio de lanzamiento posterior al actual");
        }
    }
    
    
    
    @Override
    public int hashCode() {
        return Objects.hash(nombre,anioDeLanzamiento);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof Nave n)){
            return false;
        }
        return this.nombre.equals(n.nombre) && this.anioDeLanzamiento == n.anioDeLanzamiento;       
    }

    @Override
    public String toString() {
        return "Nave{" + "nombre=" + nombre + ", capacidadDeTripulacion=" + capacidadDeTripulacion + ", anioDeLanzamiento=" + anioDeLanzamiento + '}';
    }

    public String getNombre() {
        return nombre;
    }
    
    
    
    
    
    
}
