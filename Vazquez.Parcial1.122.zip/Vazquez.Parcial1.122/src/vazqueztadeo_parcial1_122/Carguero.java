package vazqueztadeo_parcial1_122;

public class Carguero extends Nave implements Explorable,Mantenible {
    public static int MAX_CARGA = 500;
    public static int MIN_CARGA = 100;
    private int capacidadCarga;

    public Carguero(String nombre, int capacidadDeTripulacion, int anioDeLanzamiento, int capacidadCarga) { 
        super(nombre, capacidadDeTripulacion, anioDeLanzamiento);        
        validarCarga(capacidadCarga);
        this.capacidadCarga = capacidadCarga;

    }
    
    private void validarCarga(int carga){
        if (carga < MIN_CARGA || carga > MAX_CARGA){
            throw new IllegalArgumentException("Carga por fuera de los limites");
        }
    }
    
    @Override
    public void explorar(){
        System.out.println("Carguero llamado " + super.getNombre() + " realizando tareas de EXPLORACION...");
    }
    @Override
    public void realizarMantenimiento(){
        System.out.println("Carguero llamado " + super.getNombre() + " realizando tareas de MANTENIMIENTO...");
    }

    @Override
    public String toString() {
        return super.toString() + " // Carguero{" + "capacidadCarga=" + capacidadCarga + '}';
    }
   
    

}
